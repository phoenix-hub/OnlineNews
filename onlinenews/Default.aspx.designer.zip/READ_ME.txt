======================================================
   How to Install Rich Text Editor for .NET
======================================================
For ASP.NET C# projects, use instructions at net_cs/installation.htm
For ASP.NET VB projects, use instructions at net_vb/installation.htm

For MVC C# Razor projects, use instructions at mvc_cs/installation.htm
For MVC VB Razor projects, use instructions at mvc_vb/installation.htm
======================================================


